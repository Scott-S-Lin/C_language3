#include <stdio.h>

int k=5;

int x=9;

int func1(void)
{
    printf("x=%d \n", x);
    return 9;
}

