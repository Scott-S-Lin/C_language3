#include <stdio.h>

int main(void)
{
    int i, k;

    /*i=0;
    while(i<10)
    {
        printf("%d\n", i);

        continue;

        i++;
    }*/


    for(i=k=0; i<10; i++)
    {
        printf("%d %d\n", i, k);

        continue;

        k++;
    }


    return 0;
}
