#include <stdio.h>

int main()
{
    while( 1 )
    {
        printf("*");
        Sleep(100);
    }

	return 0;
}

