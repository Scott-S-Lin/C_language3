#include <stdio.h>

int main()
{
    int i;

    /*while(1)
        printf("*****\n");*/


    /*i=1;
    while(i<=5)
    {
        printf("*****\n");
        i++;
    }*/


    /*i=0;
    while(i<5)
    {
        printf("*****\n");
        i++;
    }*/


    /*i=0;
    while( i++ < 5 )
        printf("*****\n");*/


    /*i=5;
    while( i-- > 0 )
        printf("*****\n");*/


    /*i=0;
    while( i < 50 )
    {
        printf("*****\n");
        i += 10;
    }*/


    /*i=1;
    while( i < 100000 )
    {
        printf("*****\n");
        i *= 10;	// i = i * 10;
    }


    /*i=1;
    while( (i*=10) < 1000000 )
    {
        printf("*****\n");
    }*/


    return 0;
}
