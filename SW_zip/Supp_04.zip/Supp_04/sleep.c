#include <stdio.h>

int main()
{
    while(1)
    {
        sleep(1);
        printf("hello\n");
    }
    
	return 0;
}

